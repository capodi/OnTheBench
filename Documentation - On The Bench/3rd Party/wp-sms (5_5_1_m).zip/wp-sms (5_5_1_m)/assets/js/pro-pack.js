jQuery(function () {
    jQuery(".wpsms-pro-settings-wrap input").attr("disabled", "disabled");
    jQuery(".wpsms-pro-settings-wrap textarea").attr("disabled", "disabled");
    jQuery(".wpsms-pro-settings-wrap select").attr("disabled", "disabled");
    jQuery(".wpsms-pro-settings-wrap .wpsms-tab-content .button").hide();
});