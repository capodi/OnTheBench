<p>
    <label for="wpsms-verify-code"><?php _e( 'Verify code', 'wp-sms-pro' ); ?><br>
        <input type="text" value="" class="input" id="wpsms-verify-code" name="wpsms_mobile_verify_code"></label>
</p>